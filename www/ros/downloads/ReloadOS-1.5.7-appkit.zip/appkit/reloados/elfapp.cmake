# Reload OS app kit - shared by every app folder in the kit (an app's CMakeLists.txt includes it before
# project.cmake). An app is built for one board against the firmware's own configuration
# (sdkconfig.defaults plus the board's file), so LVGL's settings, the pins in ros_board.h and everything
# else match the firmware it is linked against on the device. The chip comes with the board: jc4848 and
# jc3248 are ESP32-S3s (IDF_TARGET; ESP-IDF then applies sdkconfig.defaults.esp32s3 by itself, right after
# sdkconfig.defaults), the others are ESP32-P4s.       ./build.sh <app> jc|jcv3|jc4880|jc8012|jc8012v3|ws101|evboard|matouch|jc4848|jc3248
set(ROS_ROOT "${CMAKE_CURRENT_LIST_DIR}")
set(ROS_BOARD "jc" CACHE STRING "Board: jc, jcv3, jc4880, jc8012, jc8012v3, ws101, evboard, matouch, jc4848 or jc3248")
set(IDF_TARGET esp32p4)
if(ROS_BOARD STREQUAL "jc")
    set(_ros_board_defaults "${ROS_ROOT}/sdkconfig.defaults.jc1060p470c")
elseif(ROS_BOARD STREQUAL "jcv3")       # the JC1060P470C with an ESP32-P4 rev v3.x chip: another instruction set, its own apps
    set(_ros_board_defaults "${ROS_ROOT}/sdkconfig.defaults.jc1060p470c;${ROS_ROOT}/sdkconfig.defaults.jc1060p470c_v3")
elseif(ROS_BOARD STREQUAL "jc4880")
    set(_ros_board_defaults "${ROS_ROOT}/sdkconfig.defaults.jc4880p443")
elseif(ROS_BOARD STREQUAL "jc8012")
    set(_ros_board_defaults "${ROS_ROOT}/sdkconfig.defaults.jc8012p4a1")
elseif(ROS_BOARD STREQUAL "jc8012v3")   # the JC8012P4A1 with an ESP32-P4 rev v3.x chip: its own apps
    set(_ros_board_defaults "${ROS_ROOT}/sdkconfig.defaults.jc8012p4a1;${ROS_ROOT}/sdkconfig.defaults.jc8012p4a1_v3")
elseif(ROS_BOARD STREQUAL "ws101")
    set(_ros_board_defaults "${ROS_ROOT}/sdkconfig.defaults.ws101")
elseif(ROS_BOARD STREQUAL "evboard")
    set(_ros_board_defaults "${ROS_ROOT}/sdkconfig.defaults.esp32_p4_function_ev")
elseif(ROS_BOARD STREQUAL "matouch")
    set(_ros_board_defaults "${ROS_ROOT}/sdkconfig.defaults.matouch")
elseif(ROS_BOARD STREQUAL "jc4848")
    set(_ros_board_defaults "${ROS_ROOT}/sdkconfig.defaults.jc4848s040")
    set(IDF_TARGET esp32s3)
elseif(ROS_BOARD STREQUAL "jc3248")
    set(_ros_board_defaults "${ROS_ROOT}/sdkconfig.defaults.jc3248w535")
    set(IDF_TARGET esp32s3)
else()
    message(FATAL_ERROR "ROS_BOARD must be jc, jcv3, jc4880, jc8012, jc8012v3, ws101, evboard, matouch, jc4848 or jc3248")
endif()
set(SDKCONFIG_DEFAULTS "${ROS_ROOT}/sdkconfig.defaults;${_ros_board_defaults};${ROS_ROOT}/elfapp.defaults")
set(SDKCONFIG "${CMAKE_SOURCE_DIR}/build_${ROS_BOARD}/sdkconfig")
set(EXTRA_COMPONENT_DIRS "${ROS_ROOT}/components")
# The ESP32-S3 keeps its own component lock file (dependencies.lock.esp32s3): one file would be solved again
# and rewritten at every change of chip. The property has to be set between project.cmake and project();
# CMAKE_PROJECT_INCLUDE runs the file below at the end of the real project() call, which ESP-IDF's project()
# makes before it resolves the components.
if(NOT IDF_TARGET STREQUAL "esp32p4")
    file(WRITE "${CMAKE_BINARY_DIR}/ros_elfapp_lock.cmake"
         "idf_build_set_property(DEPENDENCIES_LOCK \"${CMAKE_SOURCE_DIR}/dependencies.lock.${IDF_TARGET}\")\n")
    set(CMAKE_PROJECT_INCLUDE "${CMAKE_BINARY_DIR}/ros_elfapp_lock.cmake")
endif()
# Every name the app defines itself is bound inside the app file when it is linked: an app's own names
# never bind to a firmware export of the same name, and embedded files (_binary_*_start) are found.
# ESP-IDF 6's compiler makes LVGL 9.2.2's doubled IRAM attribute an error; it stays a warning (as in the firmware)
include($ENV{IDF_PATH}/tools/cmake/version.cmake)
if(IDF_VERSION_MAJOR GREATER_EQUAL 6)
    add_compile_options(-Wno-error=attributes)
endif()
# The app's own version: version.txt in its folder ("2.0.0" - three numbers, as the firmware's). ROS_ELFAPP_META
# (ros.h) puts it into the file's ".ros_ver" section with the app's id, the folder's name: the device shows it
# (Settings > About > Apps), tells its Reload OS Account, and an online update compares it. No version.txt: no
# section - the app loads as ever, its version unknown.
if(EXISTS "${CMAKE_SOURCE_DIR}/version.txt")
    file(STRINGS "${CMAKE_SOURCE_DIR}/version.txt" _ros_app_version LIMIT_COUNT 1)
    string(STRIP "${_ros_app_version}" _ros_app_version)
    get_filename_component(_ros_app_id "${CMAKE_SOURCE_DIR}" NAME)
    string(LENGTH "${_ros_app_version}" _ros_app_version_len)
    string(LENGTH "${_ros_app_id}" _ros_app_id_len)
    if(NOT _ros_app_version MATCHES "^[0-9]+[.][0-9]+[.][0-9]+[0-9A-Za-z.+-]*$" OR _ros_app_version_len GREATER 23)
        message(FATAL_ERROR "version.txt: \"${_ros_app_version}\" is not a version like 1.0.0 (at most 23 characters)")
    endif()
    if(NOT _ros_app_id MATCHES "^[a-z0-9_]+$" OR _ros_app_id_len GREATER 15)
        message(FATAL_ERROR "An app with a version.txt needs a folder name of a-z, 0-9 and _, at most 15 long: ${_ros_app_id}")
    endif()
    add_compile_definitions("ROS_APP_VERSION=\"${_ros_app_version}\"" "ROS_APP_ID=\"${_ros_app_id}\"")
    set_property(DIRECTORY APPEND PROPERTY CMAKE_CONFIGURE_DEPENDS "${CMAKE_SOURCE_DIR}/version.txt")
endif()
set(ELF_LIBS "-Wl,-Bsymbolic")
