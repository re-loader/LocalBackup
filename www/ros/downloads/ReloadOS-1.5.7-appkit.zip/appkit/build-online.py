#!/usr/bin/env python3
"""build-online.py - the name this command had before it became "ros" (ros.py; the kit of 2026-11-18). It still works:

    python build-online.py login | logout | boards        the same commands of ros
    python build-online.py <app> [board]                  = python ros.py build <app> [board]
"""
import os, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import ros  # noqa: E402

args = sys.argv[1:]
ros.main(args if not args or args[0] in ('login', 'logout', 'boards', '-h', '--help', 'help') else ['build'] + args)
