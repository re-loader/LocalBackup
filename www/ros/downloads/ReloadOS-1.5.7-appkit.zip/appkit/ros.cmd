@echo off
rem ros - the Reload OS app kit's command on Windows:  ros build myapp   (ros.py says what it does)
where py >nul 2>nul && (py -3 "%~dp0ros.py" %* & exit /b %errorlevel%)
python "%~dp0ros.py" %*
