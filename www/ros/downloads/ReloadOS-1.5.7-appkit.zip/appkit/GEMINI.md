# Gemini

Read `AGENTS.md` in this folder first: what an app is here, how to build one without installing anything
(`python ros.py build <app>`; `python ros.py api <name>` says what an app may call), and what an assistant must not do (the account password is the person's to type).
