#!/usr/bin/env python3
"""ros - the Reload OS app kit's command. Windows, macOS and Linux; Python 3.8 or newer, nothing to install.

    python ros.py new <app>              start an app from the Hello example -> <app>/
    python ros.py build <app> [board]    build it on Reloader's build service -> <app>/<board folder>/<app>.elf
    python ros.py boards                 the boards the service builds for (the default is jc)
    python ros.py api <words>            what an app may call: search the firmware's table and ros.h
    python ros.py login                  once: sign in with your Reload OS Account (os.re-loader.com/account)
    python ros.py whoami                 who is signed in here, this kit's version and the service's
    python ros.py devices                the devices in your account: what each runs, activated or not
    python ros.py logout                 forget the sign-in on this computer

"ros.cmd" (Windows) and "./ros" (macOS, Linux) run it without the word python:  ros build myapp

build needs no ESP-IDF on this computer: it sends the app's sources (and its pictures and sounds) to the service,
which builds them with the newest Reload OS release exactly as ./build.sh would, and saves the .elf it answers with -
or prints the compiler's errors. What the service takes - keep an app that is built this way to this:
    <app>/main/<app>.c               the app (its ROS_ELFAPP_META and its functions)
    <app>/main/ui.c, ui.h            optional: a second source and its header (what Studio exports)
    <app>/main/assets/*.png, *.wav   optional: pictures and sounds, embedded
A source is at most 128 KB and may #include headers by name only (ros.h, lvgl.h, ui.h, the C library's).

The sign-in: login asks for the account's email and password ON THE KEYBOARD, sends them to the account service over
HTTPS and keeps only the session it answers with (not the password) in ~/.reloados/session.json, for 30 days.
An AI assistant must not ask for, type or store the password: the person runs login themself. build and devices
need the sign-in; new, boards and api do not. ROS_SITE names another server (default https://os.re-loader.com).

Exit codes: 0 done, 1 an error, 2 not signed in (the person runs login), 3 the build failed (the compiler's lines).
"""
import base64, getpass, json, os, re, shutil, sys, time, urllib.error, urllib.request

SITE = os.environ.get('ROS_SITE', 'https://os.re-loader.com').rstrip('/')
KIT = os.path.dirname(os.path.abspath(__file__))
SESSION = os.path.join(os.path.expanduser('~'), '.reloados', 'session.json')
NAME = re.compile(r'^[a-z][a-z0-9_]{0,22}$')
ASSET = re.compile(r'^[a-z][a-z0-9_]{0,22}\.(png|wav)$')
MAX_SOURCE = 128 * 1024
AGENT = 'reloados-appkit'
ME = 'python ros.py'


def die(msg, code=1):
    print(msg, file=sys.stderr)
    sys.exit(code)


def call(method, path, body=None, token=None, timeout=60):
    """-> (status, headers, bytes); status 0: the server did not answer"""
    head = {'User-Agent': AGENT}
    data = None
    if body is not None:
        data = json.dumps(body).encode('utf-8')
        head['Content-Type'] = 'application/json'
    if token:
        head['Authorization'] = 'Bearer ' + token
    req = urllib.request.Request(SITE + path, data=data, headers=head, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, r.headers, r.read()
    except urllib.error.HTTPError as e:
        return e.code, e.headers, e.read()
    except (urllib.error.URLError, OSError) as e:
        return 0, {}, str(getattr(e, 'reason', e)).encode('utf-8')


def said(raw):
    try:
        j = json.loads(raw.decode('utf-8'))
        return j if isinstance(j, dict) else {}
    except ValueError:
        return {}


def session():
    try:
        with open(SESSION, encoding='utf-8') as f:
            s = json.load(f)
        return s if s.get('site') == SITE and s.get('token') else None
    except (OSError, ValueError):
        return None


def need_session():
    s = session()
    if not s:
        die(f'Not signed in. Run once, yourself, in a terminal:  {ME} login', 2)
    return s


def kit_version():
    try:
        return open(os.path.join(KIT, 'reloados', 'VERSION'), encoding='utf-8').read().split()[0]
    except (OSError, IndexError):
        return '?'


# ---------------------------------------------------------------- the account

def login():
    if not sys.stdin.isatty():
        die(f'login asks for the password on the keyboard: run it yourself in a terminal -  {ME} login')
    print(f'Sign in with your Reload OS Account ({SITE}/account - make one there first, and confirm its email).')
    try:
        email = input('Email: ').strip()
    except EOFError:
        die(f'\nNo email typed: run it in a terminal -  {ME} login')
    if re.search(r'[^\x00-\x7f]', email):
        die('Type the email address in English letters: the keyboard is on another language.')
    password = getpass.getpass('Password (not shown, not kept): ')
    status, _, raw = call('POST', '/api/account/login', {'email': email, 'password': password})
    j = said(raw)
    if status != 200 or not j.get('token'):
        if status == 0:
            die(f'{SITE} does not answer: {raw.decode("utf-8", "replace")}')
        if j.get('unverified'):
            die('This account\'s email is not confirmed yet: open the mail from Reload OS (look in Junk too) and follow its link, then log in again.')
        die(f'Not signed in: {j.get("error") or "the server answered " + str(status)}')
    os.makedirs(os.path.dirname(SESSION), exist_ok=True)
    fd = os.open(SESSION, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, 'w', encoding='utf-8') as f:
        json.dump({'site': SITE, 'email': j.get('user', {}).get('email', email), 'token': j['token']}, f)
    print(f'Signed in as {j.get("user", {}).get("email", email)}. The session is in {SESSION} (the password is not).')


def logout():
    s = session()
    if s:
        call('POST', '/api/account/logout', {}, s['token'])
    try:
        os.remove(SESSION)
    except OSError:
        pass
    print('Signed out on this computer.')


def whoami():
    print(f'This kit: Reload OS {kit_version()} in {KIT}')
    info = boards_info(fatal=False)
    print(f'The build service: {SITE}' + (f', Reload OS {info.get("kit", "?")}' if info else ' - it does not answer just now'))
    s = session()
    if not s:
        die(f'Not signed in. Run once, yourself, in a terminal:  {ME} login', 2)
    status, _, raw = call('GET', '/api/account/me', token=s['token'])
    user = said(raw).get('user') or {}
    if status == 200 and user.get('email'):
        return print(f'Signed in as {user["email"]}' + (f' ({user["name"]})' if user.get('name') else ''))
    if status == 401:
        die(f'The sign-in is no longer good (30 days, or signed out elsewhere). Run yourself:  {ME} login', 2)
    die(f'The account service does not answer ({status or raw.decode("utf-8", "replace")}); the session here is {s.get("email", "?")}\'s.')


def ago(seconds):
    if seconds is None:
        return 'never'
    d = max(0, time.time() - seconds)
    return 'just now' if d < 90 else f'{int(d / 60)} min ago' if d < 5400 else f'{int(d / 3600)} h ago' if d < 172800 else f'{int(d / 86400)} d ago'


def devices():
    s = need_session()
    status, _, raw = call('GET', '/api/account/devices', token=s['token'])
    if status == 401:
        die(f'The sign-in is no longer good. Run yourself:  {ME} login', 2)
    j = said(raw)
    if status != 200 or 'devices' not in j:
        die(f'The account service does not answer ({status or raw.decode("utf-8", "replace")}).')
    if not j['devices']:
        return print(f'No device in {s.get("email", "this account")} yet. On the device: Settings > Account > Sign in, then {SITE}/account')
    for d in j['devices']:
        seen = d.get('seen')
        if isinstance(seen, str):                                   # an ISO time or seconds: whatever the service says
            try:
                seen = time.mktime(time.strptime(seen[:19], '%Y-%m-%dT%H:%M:%S')) - time.timezone
            except ValueError:
                seen = None
        elif isinstance(seen, (int, float)) and seen > 1e11:
            seen = seen / 1000
        trial = d.get('trial', -1)
        state = ('activated' if d.get('licensed') else 'activating' if d.get('activating') else
                 'free version: apps from files are locked' if trial == 0 else f'trial, {trial} days left' if isinstance(trial, int) and trial > 0 else 'not activated')
        print(f'{d.get("name") or "(no name)"}  {d.get("device", "?")}  {d.get("board", "?")}  Reload OS {d.get("fw", "?")}  {state}  seen {ago(seen)}'
              + (f'  UPDATE: {d["latest"]} is out' if d.get('update') and d.get('latest') else ''))
        for a in d.get('apps') or []:
            print(f'    app {a.get("id", "?")}  {a.get("name", "")}  {a.get("ver") or "no version"}')


# ---------------------------------------------------------------- a new app

def new(app):
    if not NAME.match(app):
        die('An app\'s name is a-z, 0-9 and _, starting with a letter, 23 at most - it is also its file name on the device (myapp.elf).')
    if app == 'hello':
        die('hello is the example itself.')
    src, dst = os.path.join(KIT, 'hello'), os.path.join(KIT, app)
    if os.path.exists(dst):
        die(f'{dst} exists already.')
    if not os.path.isfile(os.path.join(src, 'main', 'hello.c')):
        die(f'The example is not here: {os.path.join(src, "main", "hello.c")} - run this in the app kit\'s folder.')
    title = app[0].upper() + app[1:]
    os.makedirs(os.path.join(dst, 'main'))
    for a, b in (('CMakeLists.txt', 'CMakeLists.txt'), (os.path.join('main', 'CMakeLists.txt'), os.path.join('main', 'CMakeLists.txt')),
                 (os.path.join('main', 'hello.c'), os.path.join('main', app + '.c'))):
        text = open(os.path.join(src, a), encoding='utf-8').read().replace('hello', app).replace('Hello', title)
        with open(os.path.join(dst, b), 'w', encoding='utf-8', newline='\n') as f:
            f.write(text)
    shutil.copyfile(os.path.join(src, 'main', 'idf_component.yml'), os.path.join(dst, 'main', 'idf_component.yml'))
    if len(app) <= 15:                                              # the app's own version: its id, the folder's name, is at most 15 long
        with open(os.path.join(dst, 'version.txt'), 'w', encoding='utf-8', newline='\n') as f:
            f.write('1.0.0\n')
    print(f'{app}/ made from the Hello example. Next: edit {os.path.join(app, "main", app + ".c")}, then  {ME} build {app}')


# ---------------------------------------------------------------- what an app may call

def api(words):
    table = os.path.join(KIT, 'reloados', 'api.txt')
    if not os.path.isfile(table):
        die(f'The firmware\'s table is not here: {table} - run this in the app kit\'s folder.')
    names = [l.strip() for l in open(table, encoding='utf-8') if l.strip() and not l.startswith('#')]
    s3 = os.path.join(KIT, 'reloados', 'api-esp32s3.txt')
    on_s3 = set(l.strip() for l in open(s3, encoding='utf-8')) if os.path.isfile(s3) else None
    try:
        header = open(os.path.join(KIT, 'reloados', 'main', 'ros.h'), encoding='utf-8').read().split('\n')
    except OSError:
        header = []
    if not words:
        ros = sum(1 for n in names if n.startswith('ros_'))
        return print(f'{len(names)} names an app may call ({ros} of Reload OS\'s own, ros_*; the rest LVGL 9.2.2, the C library, ESP-IDF).\n'
                     f'Search them:  {ME} api toast     {ME} api lv_label     {ME} api wifi status')
    want = [w.lower() for w in words]
    hits = [n for n in names if all(w in n.lower() for w in want)]
    exact = [n for n in names if n.lower() == ' '.join(want)]
    hits = exact + [n for n in hits if n not in exact]
    # what ros.h says where the words are only in a comment or a macro (ROS_C_TEXT, ROS_SCR_W are not in the table: no symbol)
    macros = []
    for i, line in enumerate(header):
        m = re.match(r'\s*#\s*define\s+(ROS_[A-Z0-9_]+)', line)
        if m and all(w in m.group(1).lower() for w in want):
            macros.append(line.strip())
    if not hits and not macros:
        parts = [t for w in want for t in w.split('_') if len(t) >= 4]
        near = sorted(set(n for n in names for t in parts if t in n.lower()))[:12]
        die(f'Nothing an app may call matches "{" ".join(words)}": do not use such a name - the device refuses an app that needs '
            'a function the firmware does not export.' + (f'\nNear it: {", ".join(near)}' if near else ''), 1)
    shown, printed = hits[:40], []
    for n in shown:
        code = lambda l: l.split('/*')[0].split('//')[0]            # a name in a comment is not its declaration
        decl = next((l.strip() for l in header if re.search(r'\b' + re.escape(n) + r'\s*\(', code(l)) and not l.lstrip().startswith(('*', '#'))), '')
        if not decl:
            decl = next((l.strip() for l in header if re.search(r'\bextern\b.*\b' + re.escape(n) + r'\b', code(l))), '')
        mark = '' if on_s3 is None or n in on_s3 else '   [not on the ESP32-S3 boards]'
        line = (decl[:230] if decl else n) + mark
        if line not in printed:
            printed.append(line)
            print(line)
    for line in macros[:20]:
        print(line[:230])
    if len(hits) > len(shown):
        print(f'... and {len(hits) - len(shown)} more: add a word.')
    if hits and not any(n.startswith('ros_') for n in shown):
        print('(a name without a line of ros.h is LVGL\'s, the C library\'s or ESP-IDF\'s: its own documentation says how it is called)')


# ---------------------------------------------------------------- the build

def boards_info(fatal=True):
    status, _, raw = call('GET', '/api/build/boards')
    j = said(raw)
    if status != 200 or 'boards' not in j:
        if fatal:
            die(f'The build service does not answer ({status or raw.decode("utf-8", "replace")}). Try again in a minute.')
        return None
    return j


def boards():
    info = boards_info()
    for b in info['boards']:
        print(f'{b["id"]:8} {b["name"]}  ({b["chip"]}; the file lands in <app>/{b["dir"]}/)')
    print(f'The service\'s kit: Reload OS {info.get("kit", "?")}; a sign-in is {"needed" if info.get("signin") else "not needed"}.')


def read_text(path):
    data = open(path, 'rb').read()
    if len(data) > MAX_SOURCE:
        die(f'{path} is larger than 128 KB: the build service takes no bigger source.')
    try:
        return data.decode('utf-8')
    except UnicodeDecodeError:
        die(f'{path} is not UTF-8 text.')


def collect(app):
    """the app's folder -> (files, assets) as the service takes them"""
    main_dir = os.path.join(KIT, app, 'main')
    if not os.path.isdir(main_dir):
        die(f'No app here: {os.path.join(KIT, app)} has no main/ folder. Start one:  {ME} new {app}')
    sources = sorted(f for f in os.listdir(main_dir) if f.endswith('.c'))
    headers = sorted(f for f in os.listdir(main_dir) if f.endswith('.h'))
    primary = [f for f in sources if f != 'ui.c']
    if len(primary) != 1 or [h for h in headers if h != 'ui.h']:
        die('The build service takes one app source, and ui.c / ui.h beside it:\n'
            f'  {app}/main/ has the sources {", ".join(sources) or "none"} and the headers {", ".join(headers) or "none"}.\n'
            f'  Keep the app in main/{app}.c (and main/ui.c, main/ui.h) - or build it on a computer with ESP-IDF: ./build.sh {app}')
    files = {'main/app.c': read_text(os.path.join(main_dir, primary[0]))}
    collect.source = primary[0]                     # the service calls it main/app.c: its errors are shown under this name
    for f in ('ui.c', 'ui.h'):
        if os.path.isfile(os.path.join(main_dir, f)):
            files['main/' + f] = read_text(os.path.join(main_dir, f))
    assets = {}
    adir = os.path.join(main_dir, 'assets')
    for f in sorted(os.listdir(adir)) if os.path.isdir(adir) else []:
        if f.startswith('.'):
            continue
        if not ASSET.match(f):
            die(f'{app}/main/assets/{f}: a picture or a sound is named a-z, 0-9 and _ with .png or .wav.')
        assets[f] = base64.b64encode(open(os.path.join(adir, f), 'rb').read()).decode('ascii')
    return files, assets


def build(app, board):
    if not NAME.match(app):
        die('An app\'s name is a-z, 0-9 and _, starting with a letter, 23 at most - it is also its file name on the device.')
    info = boards_info()
    known = {b['id']: b for b in info['boards']}
    if board not in known:
        die(f'The build service has no board "{board}". It builds for: ' + ', '.join(f'{b["id"]} ({b["name"]})' for b in info['boards']))
    s = session()
    if info.get('signin') and not s:
        die(f'Not signed in. Run once, yourself, in a terminal:  {ME} login', 2)
    files, assets = collect(app)
    body = {'board': board, 'name': app, 'files': files}
    if assets:
        body['assets'] = assets
    print(f'Building {app} for {known[board]["name"]} on {SITE} (its kit: Reload OS {info.get("kit", "?")}; this kit: {kit_version()}) - '
          'seconds, or minutes when the service has not built for this board lately ...', flush=True)
    status, head, raw = call('POST', '/api/build', body, s['token'] if s else None, timeout=1500)
    if status == 200:
        out = os.path.join(KIT, app, known[board]['dir'])
        os.makedirs(out, exist_ok=True)
        path = os.path.join(out, app + '.elf')
        with open(path, 'wb') as f:
            f.write(raw)
        note = head.get('X-Build-Note')
        print(f'Built in {head.get("X-Build-Seconds", "?")} s: {path} ({len(raw)} bytes)' + (f'\n{note}' if note else ''))
        print(f'Put it on the device: copy it into the apps/ folder of its flash drive or SD card, or use {SITE}/install-app.html (README.md, "Put it on the device").')
        return
    j = said(raw)
    if status == 422:
        print('The build failed - the compiler says:\n', file=sys.stderr)
        die((j.get('log') or j.get('error') or '(no error lines)').replace('main/app.c', 'main/' + collect.source), 3)
    if status == 401:
        die(f'The sign-in is no longer good (30 days, or signed out elsewhere). Run yourself:  {ME} login', 2)
    if status == 0:
        die(f'{SITE} does not answer: {raw.decode("utf-8", "replace")}')
    die(f'Not built ({status}): {j.get("error") or raw[:300].decode("utf-8", "replace")}')


def main(argv):
    if not argv or argv[0] in ('-h', '--help', 'help'):
        return print(__doc__.strip())
    cmd, rest = argv[0], argv[1:]
    name = lambda v: v.strip('/\\')                                 # a folder's name from the shell's completion: myapp/
    if cmd == 'login' and not rest:
        return login()
    if cmd == 'logout' and not rest:
        return logout()
    if cmd == 'whoami' and not rest:
        return whoami()
    if cmd == 'devices' and not rest:
        return devices()
    if cmd == 'boards' and not rest:
        return boards()
    if cmd == 'api':
        return api(rest)
    if cmd == 'new' and len(rest) == 1:
        return new(name(rest[0]))
    if cmd == 'build' and 1 <= len(rest) <= 2:
        return build(name(rest[0]), rest[1] if len(rest) > 1 else 'jc')
    die(f'{ME} {" ".join(argv)}: not a command of ros. They are:\n\n' + __doc__.strip().split('\n\n')[1])


if __name__ == '__main__':
    main(sys.argv[1:])
