# For AI assistants working in this folder

This is the **Reload OS app kit**: the folder a person builds apps in for a Reload OS device (ESP32 touch boards by
Reloader). Read `README.md` for the whole guide; this page is what an assistant needs first, and what it must not
get wrong. `GEMINI.md` and `CLAUDE.md` only point here.

## The kit's command: `ros`

`python ros.py <command>` (Windows: `ros <command>`; macOS / Linux: `./ros <command>`). Python 3, nothing to install.
Run it instead of guessing - its answers are the facts:

```
python ros.py new <app>            a new app from the Hello example
python ros.py build <app> [board]  build it online -> <app>/<board folder>/<app>.elf, or the compiler's errors
python ros.py api <words>          is this function there? what is it called?   e.g.  api toast   api lv_label set
python ros.py boards               the boards (jc is the default)
python ros.py whoami               who is signed in, this kit's version
python ros.py devices              the person's devices: board, Reload OS version, activated or not
```

Exit codes: 0 done; 2 **not signed in** - stop and ask the person to run `python ros.py login`; 3 the build failed -
read the compiler's lines, fix the source, build again; 1 anything else (the message says what).

## What an app is

- One folder beside `hello/`: `<app>/main/<app>.c`, `<app>/main/CMakeLists.txt`, `<app>/CMakeLists.txt`,
  `<app>/version.txt`. Start one with `python ros.py new <name>` - the name is a-z, 0-9 and _, starts with a letter,
  and is the file name on the device.
- It is C against `reloados/main/ros.h` and LVGL 9.2.2. **It may call only what the firmware exports**
  (`reloados/api.txt`; ESP32-S3 boards: `api-esp32s3.txt`): the device refuses a file that needs anything else.
  **Before using a function, `python ros.py api <name>`** - it prints the declaration from `ros.h`, or says there is
  no such name and lists the near ones. Do not invent `ros_*` names.
- The result is `<app>/<board folder>/<app>.elf`, built **for one board**. It does not exist until a build has
  succeeded: writing the C file does not make it.

## Building: two ways

1. **Online, no tools on this computer - the way on Windows, and whenever ESP-IDF is not installed:**
   `python ros.py build <app> [board]`. It sends the sources to Reloader's build service and saves the `.elf`, or
   prints the compiler's errors. Seconds as a rule; the first build for a board in a while takes minutes: wait for
   it, do not start a second one.
   - It needs the person's **Reload OS Account**, signed in once on this computer: `python ros.py login`.
     **The person runs that themself** - it asks for the password on the keyboard and refuses to run without a
     terminal. Never ask for the password, never put it in a command, a file or a chat.
   - An account is made at https://os.re-loader.com/account and its email must be confirmed from the mail it gets
     (it may be in Junk). The address is typed in English letters: with the keyboard on Thai the form refuses it.
   - Online, an app is **one source**, `main/<app>.c`, with `main/ui.c` and `main/ui.h` beside it if wanted, each at
     most 128 KB, including headers by name only (`ros.h`, `lvgl.h`, `ui.h`, the C library's); pictures and sounds
     in `main/assets/` (`.png`, `.wav`). More files than that: build locally.
   - The service builds with the newest Reload OS release. `python ros.py devices` shows what the person's device
     runs: an app built for a newer release than the device's may not open there - say so, and that the device
     updates in Settings > About > Check online.
2. **Locally: `./build.sh <app> [board]`** - bash on macOS or Linux with **ESP-IDF v6.1** installed (README.md,
   "Requirements"). Do not install ESP-IDF or change its version on your own: ask first - the online build needs none.

The same app can also be drawn and built in the browser: Reload OS Studio, https://os.re-loader.com/studio/ (Export ›
ELF; the file lands in the browser's Downloads folder).

## Putting it on a device

Copy the `.elf` into the `apps/` folder of the device's flash drive or SD card, or send it over USB from
https://os.re-loader.com/install-app.html (README.md, "Put it on the device"). A device that is not activated runs
apps from files during its 30-day trial only. An assistant cannot do this step: say where the file is and what
to do with it.

## Rules that restart the device when broken (README.md has them all)

- `main()` only hands the app back. No LVGL call and no work there: that starts in `create()`.
- LVGL is called on the LVGL task (in `create()`, in event and timer callbacks), or between `ros_lock()` and
  `ros_unlock()` from a task of the app's own.
- Nothing that waits (network, files, a device) on the LVGL task: a task of its own; a UI stuck for 60 s restarts
  the device. A task the app starts is counted and ends with `ros_task_end()`.
- `destroy()` stops what the app started (timers, tasks); what it keeps across opens it frees in `unload()`.
- The screen's size and way round differ by board and setting: use `ROS_SCR_W`, `ROS_SCR_H`, `ROS_PORTRAIT`
  (values read in `create()`, not constants), and the colours `ROS_C_*`.
- Big buffers come from PSRAM (`heap_caps_malloc(..., MALLOC_CAP_SPIRAM)`), not the stack or internal RAM.

## When asked "why is there no .elf?"

Run `python ros.py build <app>` and say which of these it is, from its answer - not a guess: no build was run yet;
the build failed (show the compiler's lines); the person is not signed in (they run `python ros.py login`); the
account's email is not confirmed; or the build service did not answer (try again in a minute).
