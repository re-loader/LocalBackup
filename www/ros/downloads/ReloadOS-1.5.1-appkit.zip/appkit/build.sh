#!/bin/bash
# Build an app of the Reload OS app kit for one board (README.md):
#   ./build.sh hello            -> hello/jc1060p470c/hello.elf      JC1060P470C, the production board
#   ./build.sh hello matouch    -> hello/matouch-p4-7/hello.elf     Makerfabs MaTouch ESP32-P4 7"
#   ./build.sh hello jc4880     -> hello/jc4880p443/hello.elf       Guition JC4880P443 4.3" (480x800)
#   ./build.sh hello jc8012     -> hello/jc8012p4a1/hello.elf       Guition JC8012P4A1 10.1" (800x1280)
#   ./build.sh hello ws101      -> hello/ws-touch-lcd-101/hello.elf Waveshare ESP32-P4-WIFI6-Touch-LCD-10.1 (800x1280)
#   ./build.sh hello evboard    -> hello/esp32-p4-function-ev/hello.elf Espressif ESP32-P4-Function-EV-Board (1024x600)
#   ./build.sh hello jc4848     -> hello/jc4848s040/hello.elf       Guition JC4848S040 4" (480x480) - an ESP32-S3
#   ./build.sh hello jc3248     -> hello/jc3248w535/hello.elf       Guition JC3248W535 3.5" (320x480) - an ESP32-S3
# Needs ESP-IDF v6.1 (the firmware's version), installed for the ESP32-P4 - and for the ESP32-S3 too when you build
# for the JC4848S040 or the JC3248W535 (its Xtensa compiler). Then copy the .elf into the apps/ folder of the
# device's flash drive or SD card. The build also checks that everything the app calls is in the firmware's table
# (reloados/api.txt; the S3's is api-esp32s3.txt) - a device refuses an app that needs more.
self="$(cd "$(dirname "$0")" && pwd)/$(basename "$0")"
cd "$(dirname "$0")" || exit 1
name=$1 board=${2:-jc}
[ -n "$name" ] && [ -f "$name/CMakeLists.txt" ] || { echo "usage: ./build.sh <app folder> [jc|jc4880|jc8012|ws101|evboard|matouch|jc4848|jc3248]"; exit 1; }
chip=esp32p4
case "$board" in
  jc) bname=jc1060p470c ;;
  jc4880) bname=jc4880p443 ;;
  jc8012) bname=jc8012p4a1 ;;
  ws101) bname=ws-touch-lcd-101 ;;
  evboard) bname=esp32-p4-function-ev ;;
  matouch) bname=matouch-p4-7 ;;
  jc4848) bname=jc4848s040; chip=esp32s3 ;;
  jc3248) bname=jc3248w535; chip=esp32s3 ;;
  *) echo "board: jc (JC1060P470C), jc4880 (JC4880P443), jc8012 (JC8012P4A1), ws101 (Waveshare Touch-LCD-10.1), evboard (Espressif ESP32-P4-Function-EV-Board), matouch (MaTouch), jc4848 (JC4848S040, ESP32-S3) or jc3248 (Guition JC3248W535, ESP32-S3)"; exit 1 ;;
esac
# The firmware's ESP-IDF: v6.1 (Reload OS 1.5.0 and later) - an app from another version does not match the
# firmware's C library and structures. The terminal may hold another one
# (VS Code's ESP-IDF extension picks the newest installed): then the build starts again in a clean environment and
# takes an installation of the wanted version it finds (one export.sh sourced over another version's leaves tools
# like cmake off the PATH). Apps built with the 1.4.0 kit (v5.5.4) keep working on 1.5.0.
want=v6.1
idf_ver() { command -v idf.py >/dev/null 2>&1 && idf.py --version 2>/dev/null | grep -o 'v[0-9][0-9.]*' | head -1; }
ver=$(idf_ver)
if [ -n "$ver" ] && [ "$ver" != "$want" ] && [ -z "$ROS_APPKIT_CLEAN" ]; then
  echo "(ESP-IDF $ver in this terminal - building with $want)"
  exec env -i HOME="$HOME" USER="$USER" TERM="${TERM:-xterm}" LANG="${LANG:-en_US.UTF-8}" ROS_APPKIT_CLEAN=1 \
    PATH=/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin bash "$self" "$@"
fi
if [ "$ver" != "$want" ]; then
  for e in ~/.espressif/tools/activate_idf_$want.sh ~/.espressif/$want/esp-idf/export.sh ~/esp/$want/esp-idf/export.sh \
           ~/esp/esp-idf-$want/export.sh ~/esp/esp-idf/export.sh; do
    [ -f "$e" ] || continue
    case $e in
      */activate_idf_*)
        # the ESP-IDF Installation Manager's: it exits when a bash script sources it (it takes $0 for the shell's name
        # to tell) - its -e prints the variables instead, PATH as its tools' folders only (idf.py a shim there)
        while IFS= read -r kv; do
          case $kv in
            PATH=*) PATH="${kv#PATH=}:$PATH" ;;
            SYSTEM_PATH=*|'') ;;
            *=*) export "$kv" ;;
          esac
        done < <(bash "$e" -e 2>/dev/null)
        export PATH ;;
      *) . "$e" >/dev/null 2>&1 ;;
    esac
    [ "$(idf_ver)" = "$want" ] && break
  done
  if [ "$(idf_ver)" != "$want" ]; then
    echo "ESP-IDF $want is needed (found: ${ver:-none}). Install $want (README.md, Requirements), or run its"
    echo "export.sh in this terminal first. In VS Code: the ESP-IDF version in the status bar -> $want."
    exit 1
  fi
fi
# The ESP32-S3 board's compiler: export.sh puts on PATH the toolchains ESP-IDF was installed for. An installation
# made for the ESP32-P4 alone has the Xtensa one next to it only when it was added later - say how.
if [ "$chip" = esp32s3 ] && ! command -v xtensa-esp32s3-elf-gcc >/dev/null 2>&1; then
  xv=$(python3 -c "import json,sys; t=json.load(open(sys.argv[1]))['tools']; print([x for x in t if x['name']=='xtensa-esp-elf'][0]['versions'][0]['name'])" "$IDF_PATH/tools/tools.json" 2>/dev/null)
  xbin=${IDF_TOOLS_PATH:-$HOME/.espressif/tools}/xtensa-esp-elf/$xv/xtensa-esp-elf/bin
  if [ -n "$xv" ] && [ -x "$xbin/xtensa-esp32s3-elf-gcc" ]; then
    export PATH="$xbin:$PATH"
  else
    echo "This board is an ESP32-S3: its compiler is not installed. Add the target to your ESP-IDF $want:"
    echo "    \$IDF_PATH/install.sh esp32p4,esp32s3      (then run export.sh again)"
    exit 1
  fi
fi

cd "$name" || exit 1
# a configuration file newer than the app's sdkconfig (the kit was updated) makes it again
cfg="build_$board/sdkconfig"
for d in ../reloados/sdkconfig.defaults ../reloados/sdkconfig.defaults.* ../reloados/elfapp.defaults; do
  [ -f "$cfg" ] && [ "$d" -nt "$cfg" ] && { rm -f "$cfg"; break; }
done
mkdir -p "build_$board"
log="build_$board/build.log"
# only the "elf" target: the ordinary firmware link of an app can't work - what it calls is the
# firmware's, found when the app is loaded on the device
if ! idf.py -B "build_$board" -D "ROS_BOARD=$board" elf > "$log" 2>&1; then
  echo "BUILD FAILED - $name/$log:"
  grep -n "error" "$log" | head
  exit 1
fi
mkdir -p "$bname"
cp "build_$board/$name.app.elf" "$bname/$name.elf"
size=$(stat -f %z "$bname/$name.elf" 2>/dev/null || stat -c %s "$bname/$name.elf")
echo "$name/$bname/$name.elf: $size bytes"

# every name the app needs from outside must be in the firmware's table - the table of the app's chip
api=../reloados/api.txt; readelf=riscv32-esp-elf-readelf
[ "$chip" = esp32s3 ] && { api=../reloados/api-esp32s3.txt; readelf=xtensa-esp32s3-elf-readelf; }
miss=$(LC_ALL=C $readelf -sW "$bname/$name.elf" 2>/dev/null | awk '$7 == "UND" && $8 != "" { print $8 }' | LC_ALL=C sort -u |
       LC_ALL=C comm -23 - <(LC_ALL=C sort -u "$api"))
if [ -n "$miss" ]; then
  echo "NOT USABLE on Reload OS $(head -1 ../reloados/VERSION): it calls what the firmware does not export:"
  echo "$miss" | sed 's/^/    /'
  echo "reloados/$(basename "$api") lists what an app can call on this board (README.md, 'What an app can call')."
  exit 1
fi
echo "OK: copy it into the apps/ folder of the device's flash drive or SD card and restart the device (README.md)"
