# Reload OS app kit - shared by every app folder in the kit (an app's CMakeLists.txt includes it before
# project.cmake). An app is built for one board against the firmware's own configuration
# (sdkconfig.defaults plus the board's file), so LVGL's settings, the pins in ros_board.h and everything
# else match the firmware it is linked against on the device. The chip comes with the board: jc4848 and
# jc3248 are ESP32-S3s (IDF_TARGET; ESP-IDF then applies sdkconfig.defaults.esp32s3 by itself, right after
# sdkconfig.defaults), the others are ESP32-P4s.       ./build.sh <app> jc|jc4880|jc8012|ws101|evboard|matouch|jc4848|jc3248
set(ROS_ROOT "${CMAKE_CURRENT_LIST_DIR}")
set(ROS_BOARD "jc" CACHE STRING "Board: jc, jc4880, jc8012, ws101, evboard, matouch, jc4848 or jc3248")
set(IDF_TARGET esp32p4)
if(ROS_BOARD STREQUAL "jc")
    set(_ros_board_defaults "${ROS_ROOT}/sdkconfig.defaults.jc1060p470c")
elseif(ROS_BOARD STREQUAL "jc4880")
    set(_ros_board_defaults "${ROS_ROOT}/sdkconfig.defaults.jc4880p443")
elseif(ROS_BOARD STREQUAL "jc8012")
    set(_ros_board_defaults "${ROS_ROOT}/sdkconfig.defaults.jc8012p4a1")
elseif(ROS_BOARD STREQUAL "ws101")
    set(_ros_board_defaults "${ROS_ROOT}/sdkconfig.defaults.ws101")
elseif(ROS_BOARD STREQUAL "evboard")
    set(_ros_board_defaults "${ROS_ROOT}/sdkconfig.defaults.esp32_p4_function_ev")
elseif(ROS_BOARD STREQUAL "matouch")
    set(_ros_board_defaults "${ROS_ROOT}/sdkconfig.defaults.matouch")
elseif(ROS_BOARD STREQUAL "jc4848")
    set(_ros_board_defaults "${ROS_ROOT}/sdkconfig.defaults.jc4848s040")
    set(IDF_TARGET esp32s3)
elseif(ROS_BOARD STREQUAL "jc3248")
    set(_ros_board_defaults "${ROS_ROOT}/sdkconfig.defaults.jc3248w535")
    set(IDF_TARGET esp32s3)
else()
    message(FATAL_ERROR "ROS_BOARD must be jc, jc4880, jc8012, ws101, evboard, matouch, jc4848 or jc3248")
endif()
set(SDKCONFIG_DEFAULTS "${ROS_ROOT}/sdkconfig.defaults;${_ros_board_defaults};${ROS_ROOT}/elfapp.defaults")
set(SDKCONFIG "${CMAKE_SOURCE_DIR}/build_${ROS_BOARD}/sdkconfig")
set(EXTRA_COMPONENT_DIRS "${ROS_ROOT}/components")
# The ESP32-S3 keeps its own component lock file (dependencies.lock.esp32s3): one file would be solved again
# and rewritten at every change of chip. The property has to be set between project.cmake and project();
# CMAKE_PROJECT_INCLUDE runs the file below at the end of the real project() call, which ESP-IDF's project()
# makes before it resolves the components.
if(NOT IDF_TARGET STREQUAL "esp32p4")
    file(WRITE "${CMAKE_BINARY_DIR}/ros_elfapp_lock.cmake"
         "idf_build_set_property(DEPENDENCIES_LOCK \"${CMAKE_SOURCE_DIR}/dependencies.lock.${IDF_TARGET}\")\n")
    set(CMAKE_PROJECT_INCLUDE "${CMAKE_BINARY_DIR}/ros_elfapp_lock.cmake")
endif()
# Every name the app defines itself is bound inside the app file when it is linked: an app's own names
# never bind to a firmware export of the same name, and embedded files (_binary_*_start) are found.
# ESP-IDF 6's compiler makes LVGL 9.2.2's doubled IRAM attribute an error; it stays a warning (as in the firmware)
include($ENV{IDF_PATH}/tools/cmake/version.cmake)
if(IDF_VERSION_MAJOR GREATER_EQUAL 6)
    add_compile_options(-Wno-error=attributes)
endif()
set(ELF_LIBS "-Wl,-Bsymbolic")
