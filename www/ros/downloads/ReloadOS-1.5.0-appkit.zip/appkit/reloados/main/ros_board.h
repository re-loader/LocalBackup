/*
 * Reload OS — what differs between the boards it runs on (chosen with CONFIG_ROS_BOARD_*).
 *
 * The ESP32-P4 boards are after Espressif's reference design with GT911 touch, an ES8311 codec and an
 * ESP32-C6 on SDIO, on the same pins for I2C (7/8), I2S clocks (13/12/10/9), SD (39-44), SDIO (14-19,
 * reset 54) and backlight (23). Everything else is here, and in the BSP header for the pins the BSP
 * drives itself (components/espressif__esp32_p4_function_ev_board/include/bsp/esp32_p4_function_ev_board.h).
 * The ESP32-S3 boards - the Guition JC4848S040 and JC3248W535 - have their own blocks first and each its own BSP with
 * the same API (components/bsp_jc4848s040, components/bsp_jc3248w535; the root CMakeLists.txt picks the chip and the
 * BSP with the board).
 *
 * (The Guition JC8012P4A1 - 10.1" 800x1280 JD9365 in two panel versions, GSL3680 touch, console on its CH340 -
 * and the Waveshare ESP32-P4-WIFI6-Touch-LCD-10.1 - 10.1" 800x1280 JD9365, GT9271 touch, microphones on an
 * ES7210, console on its CH343 - and Espressif's own ESP32-P4-Function-EV-Board, the reference design itself with
 * its 7" EK79007 kit, console on its CP2102N - have their own blocks below.)
 *                       MaTouch ESP32-P4 7"        Guition JC1060P470C         Guition JC4880P443
 *   panel               7" 1024x600 JD9165         7" 1024x600 JD9165          4.3" 480x800 ST7701 (vertical)
 *   LCD reset           IO27                       IO0                         IO5
 *   backlight (IO23)    PWM inverted               PWM not inverted (MP3202)   PWM not inverted
 *   touch INT           not wired                  IO21 (not used: polled)     IO21 (not used: polled)
 *   I2S data in         IO11                       IO48                        IO48
 *   speaker amp enable  IO53                       IO11                        IO11
 *   microSD power       IO45 (P-MOSFET, low = on)  always on (LDO 4)           always on (LDO 4)
 *   Ethernet            IP101 (RMII)               IP101 (RMII)                none
 *   clock chip          none (P4 LP timer)         RX8025T on I2C, 0x32, CR1220  none (NTP)
 *   card socket         IO32/33/46/47/48 (header)  IO5/2/3/4/1 (on board)      none (IO1-4 not routed)
 *   BP monitor          USB, or serial on IO4      USB, or RS-232: IO45 (V002)  USB
 *   barcode / QR        USB (keyboard type)        USB, or serial: IO20 (V002)  USB
 *   camera              SC2336                     OV02C10 (components/ov02c10)  OV02C10 (not checked yet)
 *   console             UART0 + USB Serial/JTAG    USB Serial/JTAG only        USB Serial/JTAG only
 * JC4880P443 values: its schematic (JC4880P443_V1.0, 2025-09-27) and the earlier port in
 * ~/Documents/RLD_ReloadOS_JC4880P443 (src/RLD_Config.h), which ran on the board in 2026-09.
 */
#pragma once
#include "sdkconfig.h"
#include "soc/soc_caps.h"

#if CONFIG_ROS_BOARD_JC3248W535

/* Guition JC3248W535 (ESP32-S3-WROOM-1 N16R8: 16 MB flash, 8 MB octal PSRAM). A 3.5" 320x480 AXS15231B on QSPI - the
 * panel keeps the picture in its own memory and takes it only as a whole frame (components/bsp_jc3248w535) - with its
 * own touch controller on I2C (4 / 8, 0x3B), a microSD slot on the SD host (1 bit), an NS4168 amplifier on I2S (no
 * codec, no microphone), a Li-ion socket with its voltage on IO5 (not read yet). The USB-C socket is the S3's own USB
 * (IO19 / 20): flash, console and probe over USB Serial/JTAG - no USB host, no PC link (they would take the console).
 * Wi-Fi and Bluetooth are the S3's own. Mounted vertically, the panel's own way (the APGAR timer on this board).
 * Values from the vendor's board support as the APGAR timer runs it (~/Documents/APGAR_TIMER, ESP-IDF 5.5.4). */
#define ROS_BOARD_NAME          "Guition JC3248W535"
#define ROS_BOARD_SHORT         "JC3248W535"
#define ROS_BOARD_CAMERA        "none on this board"
#define ROS_BOARD_HAS_CAMERA    0
#define ROS_BOARD_SD_PWR_GPIO   (-1)       /* always powered */
#define ROS_BOARD_RTC_RX8025T   0          /* no clock chip: NTP */
#define ROS_BOARD_CLOCK_BACKUP  0
#define ROS_BOARD_PANEL_NAME    "3.5\"  320 x 480  AXS15231B, QSPI"
#define ROS_BOARD_PANEL_W       320        /* the panel's own scan: vertical */
#define ROS_BOARD_PANEL_H       480
#define ROS_BOARD_TOUCH_NAME    "AXS15231B"  /* the panel's own touch controller (bsp_jc3248w535) */
#define ROS_BOARD_TOUCH_GT911   0
#define ROS_BOARD_DEFAULT_ORIENT ROS_ORIENT_VERTICAL     /* 320x480, the panel's own way */
#define ROS_BOARD_HAS_ETH       0
#define ROS_BOARD_HAS_USB       0          /* IO19 / 20: the console (USB Serial/JTAG) */
#define ROS_BOARD_USB_FS_PORT   0
#define ROS_BOARD_HAS_MIC       0          /* the NS4168 only plays */
#define ROS_BOARD_AUDIO_CODEC   "none: I2S straight to the amplifier, 16 kHz 16-bit mono"
#define ROS_BOARD_AUDIO_AMP     "NS4168, class-D with I2S input"
#define ROS_BOARD_FLASH_MB      16         /* the module's N16R8 */
#define ROS_BOARD_PSRAM_MB      8
#define ROS_BOARD_CONSOLE_UART  0          /* console and probe on USB Serial/JTAG */
#define ROS_BOARD_BP_RX         (-1)
#define ROS_BOARD_BP_RX_NAME    ""
#define ROS_BOARD_SCAN_RX       (-1)
#define ROS_BOARD_SCAN_RX_NAME  ""
#define ROS_SCG_PIN_IO          (-1)
#define ROS_SCG_PIN_CLK         (-1)
#define ROS_SCG_PIN_RST         (-1)
#define ROS_SCG_PIN_VCC         (-1)
#define ROS_SCG_PIN_DET         (-1)

#elif CONFIG_ROS_BOARD_JC4848S040

/* Guition JC4848S040 (ESP32-S3-WROOM-1 N16R8: 16 MB flash, 8 MB octal PSRAM). A 4" 480x480
 * ST7701S on a 16-bit RGB bus (the panel's set-up lines are bit-banged once at start), GT911 touch on I2C 19/45, a
 * microSD slot on SPI (it shares SCK / MOSI 48 / 47 with the panel's set-up lines), an NS4168 amplifier on I2S (no
 * codec, no microphone), the console on a CH340C on UART0 (IO43/44). Wi-Fi and Bluetooth are the S3's own: no
 * co-processor. The screen takes 26 GPIOs, 19 and 20 among them, so the S3's USB is not usable at all: no USB host, no
 * PC link. Free: IO1, 2, 40 (the amplifier, or relays on H1 with R25-R27 fitted instead), 41 / 42 (the card), 43 / 44.
 * Values from the K-LINE dash (~/Documents/K-LINE, main/display.c), which runs on this board with ESP-IDF 5.5.4. */
#define ROS_BOARD_NAME          "Guition JC4848S040"
#define ROS_BOARD_SHORT         "JC4848S040"
#define ROS_BOARD_CAMERA        "none on this board"
#define ROS_BOARD_HAS_CAMERA    0
#define ROS_BOARD_SD_PWR_GPIO   (-1)       /* always powered */
#define ROS_BOARD_RTC_RX8025T   0          /* no clock chip: NTP */
#define ROS_BOARD_CLOCK_BACKUP  0
#define ROS_BOARD_PANEL_NAME    "4\"  480 x 480  ST7701S, RGB 16-bit"
#define ROS_BOARD_PANEL_W       480
#define ROS_BOARD_PANEL_H       480
#define ROS_BOARD_HAS_ETH       0
#define ROS_BOARD_HAS_USB       0          /* IO19 / 20 are touch SDA and the panel's G1 */
#define ROS_BOARD_USB_FS_PORT   0
#define ROS_BOARD_HAS_MIC       0          /* the NS4168 only plays */
#define ROS_BOARD_AUDIO_CODEC   "none: I2S straight to the amplifier, 16 kHz 16-bit mono"
#define ROS_BOARD_AUDIO_AMP     "NS4168, class-D with I2S input"
#define ROS_BOARD_FLASH_MB      16         /* the module's N16R8 */
#define ROS_BOARD_PSRAM_MB      8
#define ROS_BOARD_CONSOLE_UART  1          /* the CH340C on UART0: console and probe */
#define ROS_BOARD_BP_RX         (-1)
#define ROS_BOARD_BP_RX_NAME    ""
#define ROS_BOARD_SCAN_RX       (-1)
#define ROS_BOARD_SCAN_RX_NAME  ""
#define ROS_SCG_PIN_IO          (-1)
#define ROS_SCG_PIN_CLK         (-1)
#define ROS_SCG_PIN_RST         (-1)
#define ROS_SCG_PIN_VCC         (-1)
#define ROS_SCG_PIN_DET         (-1)

#elif CONFIG_ROS_BOARD_JC1060F570C

/* Guition JC1060F570C (ESP32-S31-WROOM-1: 16 MB flash, 16 MB PSRAM; built with ESP-IDF master, where the S31 is a
 * preview chip). A 7" 1024x600 JD9165 on the S31's 16-bit RGB bus, GT911 touch on I2C 2 / 3, an ES8389 codec on the same
 * bus with I2S on 54 / 47 / 56 / 16 and its amplifier on IO42, a microSD slot on SDMMC (4-bit, 24 / 25 / 20-23), an
 * RMII Ethernet PHY, an RX8025 clock chip. Wi-Fi and Bluetooth are the S31's own: no co-processor. Pins from the
 * vendor's demo (JC1060F570-FactoryDemo, its esp_board_manager files) and schematic JC1060F570_V1.0 - see
 * docs/drivers/jc1060f570.md. First port: the display, touch, backlight, card, Wi-Fi, Bluetooth and the clock chip;
 * then Ethernet and the microphone (2026-11-10, the day it first ran on a board); USB is off: the bench board's
 * socket passes no data (below). */
#define ROS_BOARD_NAME          "Guition JC1060F570C"
#define ROS_BOARD_SHORT         "JC1060F570C"
#define ROS_BOARD_CAMERA        "none on this board"
#define ROS_BOARD_HAS_CAMERA    0
#define ROS_BOARD_SD_PWR_GPIO   (-1)       /* always powered */
#define ROS_BOARD_RTC_RX8025T   1          /* I2C, on the touch / codec bus */
#define ROS_BOARD_PANEL_NAME    "7\"  1024 x 600  JD9165, RGB 16-bit"
#define ROS_BOARD_PANEL_W       1024
#define ROS_BOARD_PANEL_H       600
#define ROS_BOARD_HAS_ETH       1          /* an IP101 on RMII, wired its own way (below) */
/* Its RMII pins, from the vendor's demo (sdkconfig: CONFIG_ETHERNET_RMII_*) and the schematic: ESP-IDF's default
 * EMAC wiring for the S31 is RGMII on other pins, so ros_eth.c sets these. The data pins are IO MUX pins of the S31's
 * EMAC (esp_hal_emac/esp32s31/emac_periph.c lists 13 / 12 / 8 / 9 / 15 / 19 / 18); MDC / MDIO go through the matrix. */
#define ROS_BOARD_ETH_RMII_PINS 1
#define ROS_BOARD_ETH_MDC       53
#define ROS_BOARD_ETH_MDIO      10
#define ROS_BOARD_ETH_REF_CLK   13         /* 50 MHz from the PHY, in */
#define ROS_BOARD_ETH_TX_EN     12
#define ROS_BOARD_ETH_TXD0      8
#define ROS_BOARD_ETH_TXD1      9
#define ROS_BOARD_ETH_CRS_DV    15
#define ROS_BOARD_ETH_RXD0      19
#define ROS_BOARD_ETH_RXD1      18
#define ROS_BOARD_ETH_RST_GPIO  17
#define ROS_BOARD_HAS_USB       1          /* The S31's one USB OTG (high-speed, its own PHY) is on the board's second
                                            * Type-C (the one that is not the console's), wired as a device's socket
                                            * (CC pulled down, its 5 V the board's input): the PC link by default, the
                                            * USB host if Settings > USB says so (ROS_USB_ONE_HS_PORT; a host needs an
                                            * OTG adapter). On since 2026-11-12: the host reads a flash drive at
                                            * full and at high speed on the second bench board; the first board's
                                            * socket passes no data - its D- does not reach the chip, that board's
                                            * fault (docs/drivers/jc1060f570.md "USB") */
#define ROS_BOARD_USB_FS_PORT   1          /* that socket can be the PC link (ros_usbdev.c) */
#define ROS_BOARD_USB_VBUS_OUT  1          /* that socket's VBUS is the board's own 5 V input: it feeds 5 V out towards a
                                            * computer, and a Type-C host that finds VBUS present does not attach - the
                                            * PC link needs a USB-A port or a hub (an A-to-C cable); 2026-11-12 */
#define ROS_BOARD_HAS_MIC       1          /* two on the ES8389's ADC; MIC1 is read (2026-11-10) */
#define ROS_BOARD_AUDIO_CODEC   "ES8389, 16 kHz 16-bit mono (duplex I2S)"
#define ROS_BOARD_AUDIO_CHIP    "ES8389"
#define ROS_BOARD_AUDIO_AMP     "class-D on IO42"
#define ROS_BOARD_FLASH_MB      16
#define ROS_BOARD_PSRAM_MB      16
#define ROS_BOARD_BP_RX         (-1)
#define ROS_BOARD_BP_RX_NAME    ""
#define ROS_BOARD_SCAN_RX       (-1)
#define ROS_BOARD_SCAN_RX_NAME  ""
#define ROS_SCG_PIN_IO          (-1)
#define ROS_SCG_PIN_CLK         (-1)
#define ROS_SCG_PIN_RST         (-1)
#define ROS_SCG_PIN_VCC         (-1)
#define ROS_SCG_PIN_DET         (-1)

#elif CONFIG_ROS_BOARD_ESP32_S31_KORVO_1

/* Espressif ESP32-S31-Korvo-1 V1.1 (ESP32-S31-WROOM-3: 16 MB flash, 16 MB PSRAM; ESP-IDF master, as the JC1060F570C)
 * with the 4.3" 800x480 subboard ESP32-S3-LCD-EV-Board-SUB3 on its LCD connector: an ST7262 on the 16-bit RGB bus
 * (no set-up commands; DISP on IO38), GT1151 touch and the ES8389 codec on I2C 0 / 1, I2S on 3 / 4 / 5 / 6 with two
 * NS4150B amplifiers on IO7 and two microphones, a microSD slot on SDMMC (4-bit, 24 / 25 / 20-23) behind a power
 * switch (IO39, low = on), a DVP camera (OV3660), a WS2812 LED, four buttons on one ADC input. The UART port's USB
 * bridge (a CP210x) is UART0: flash, console and probe. Pins from Espressif's user guide and its BSP (esp-bsp
 * esp32_s31_korvo_1 1.1.0) - see docs/drivers/esp32-s31-korvo-1.md. First port: the display, touch, card, speaker,
 * Wi-Fi and Bluetooth; the microphones, camera, USB, LED and buttons are still to come. */
#define ROS_BOARD_NAME          "Espressif ESP32-S31-Korvo-1"
#define ROS_BOARD_SHORT         "S31-Korvo-1"
#define ROS_BOARD_CAMERA        "OV3660 (DVP): not used yet"
#define ROS_BOARD_HAS_CAMERA    0
#define ROS_BOARD_SD_PWR_GPIO   (-1)       /* IO39, switched on by the board support (bsp_sdcard_card_init) */
#define ROS_BOARD_RTC_RX8025T   0          /* no clock chip: NTP */
#define ROS_BOARD_CLOCK_BACKUP  0
#define ROS_BOARD_PANEL_NAME    "4.3\"  800 x 480  ST7262, RGB 16-bit"
#define ROS_BOARD_PANEL_W       800
#define ROS_BOARD_PANEL_H       480
#define ROS_BOARD_TOUCH_NAME    "GT1151"
#define ROS_BOARD_TOUCH_GT911   0
#define ROS_BOARD_HAS_ETH       0          /* none */
#define ROS_BOARD_HAS_USB       1          /* the S31's USB OTG on the Type-A socket: the USB host (a flash drive read
                                            * there 2026-11-10) */
#define ROS_BOARD_USB_FS_PORT   0          /* a host socket: no PC link */
#define ROS_BOARD_HAS_MIC       0          /* the ES8389's ADC, two microphones: the JC1060F570C's code, not run here yet */
#define ROS_BOARD_AUDIO_CODEC   "ES8389, 16 kHz 16-bit mono"
#define ROS_BOARD_AUDIO_CHIP    "ES8389"
#define ROS_BOARD_AUDIO_AMP     "2 x NS4150B, 3 W class-D"
#define ROS_BOARD_FLASH_MB      16
#define ROS_BOARD_PSRAM_MB      16
#define ROS_BOARD_CONSOLE_UART  1          /* the CP210x on UART0: console and probe */
#define ROS_BOARD_BP_RX         (-1)
#define ROS_BOARD_BP_RX_NAME    ""
#define ROS_BOARD_SCAN_RX       (-1)
#define ROS_BOARD_SCAN_RX_NAME  ""
#define ROS_SCG_PIN_IO          (-1)
#define ROS_SCG_PIN_CLK         (-1)
#define ROS_SCG_PIN_RST         (-1)
#define ROS_SCG_PIN_VCC         (-1)
#define ROS_SCG_PIN_DET         (-1)

#elif CONFIG_ROS_BOARD_JC1060P470C

#define ROS_BOARD_NAME          "Guition JC1060P470C"
#define ROS_BOARD_SHORT         "JC1060P470C"
#define ROS_BOARD_CAMERA        "OV02C10  1288x728"     /* components/ov02c10, MIPI-CSI 1 lane */
#define ROS_BOARD_SD_PWR_GPIO   (-1)       /* TF_VCC: LDO 4 through an always-on switch */
#define ROS_BOARD_RTC_RX8025T   1          /* I2C 0x32 on the touch / codec bus */
/* USB: two Type-C on the P4 - the USB Serial/JTAG (IO24/25: the console, the probe, flashing) and the high-speed OTG
 * ("USB Native": the host; 5 V out through D12). The P4's full-speed OTG (IO26/27) has NO socket on this board: those
 * pins are the MAX485 (RS485). So the one usable socket is the USB host, or the PC link - TinyUSB on the high-speed
 * port - by Settings > USB, and a kiosk keeps the host unless told otherwise (ros.h, the setting's reading per board).
 * Found 2026-11-12: the "USB_OTG drive for PC" of the default config had talked to the RS485 chip. */
#define ROS_BOARD_USB_FS_PORT   0
#define ROS_BOARD_USB_HS_DEVICE 1
#define ROS_BOARD_USB_VBUS_OUT  1          /* the socket's 5 V comes from the board: a Type-C computer port may not attach */
/* Blood-pressure monitor: USB (a CDC-ACM device), or RS-232 on the V003 I/O
 * board's P4 - InBody BPBIO 750, Yuwell, Terumo, V20: MAX3232E -> header pin 12, IO46 (V003's P4 also sends, from
 * IO20 with its JP1 moved). The V002 board had it on IO45 (pin 14): set 45 for one of those. */
#define ROS_BOARD_BP_RX         46         /* V003 P4 (RS232) -> MAX3232E -> header pin 12 */
#define ROS_BOARD_BP_RX_NAME    "V003 P4"
/* Barcode / QR scanner: RS-232 on the V003 I/O board's P3 (QRCODE) -> MAX3232E -> header pin 10, IO47. The V002
 * board had it on IO20 (pin 17), and before V002 it was port U0 (IO38): set 20 / 38 for those. */
#define ROS_BOARD_SCAN_RX       47
#define ROS_BOARD_SCAN_RX_NAME  "V003 P3"
/* Other serial inputs: the option pins IO20 / IO45 (header pins 17 / 14), straight out on the V003 I/O board's P6
 * (EXT: GND IO20 IO45 5V, 3.3 V logic) - a TTL device there can be the monitor's or the scanner's input. With V003's
 * solder jumpers moved (JP1 / JP2) the same pins drive the RS-232 transmitters instead: IO20 -> P4's TX, IO45 ->
 * P3's (no firmware sends yet). On a V002 board they are its two receive pins. */
#define ROS_BOARD_SERIAL_RX_ALT { 20, 45 }
/* The kiosk app's two guide LEDs, high = on (GPIO -> 330 R -> LED -> GND): the V003 I/O board's 5 mm front LEDs - the card
 * LED is LED1 + LED3 (bottom and top of the card slot, in parallel) on IO33 (header pin 21), the QR LED is LED2
 * (middle) on IO32 (pin 19). V003's sensors are on the JC's own I2C (pins 23 / 25), which leaves IO32 / IO33 free. */
#define ROS_BOARD_LED_CARD      33
#define ROS_BOARD_LED_CODE      32
/* Smart-card socket on the board: C7 I/O, C3 CLK, C2 RST, card power, card switch (low = in) */
#define ROS_SCG_PIN_IO          5
#define ROS_SCG_PIN_CLK         2
#define ROS_SCG_PIN_RST         3
#define ROS_SCG_PIN_VCC         4
#define ROS_SCG_PIN_DET         1

#elif CONFIG_ROS_BOARD_JC8012P4A1

/* Guition JC8012P4A1 (schematic JC8012P4A1 V1.0, 2024-11; the vendor's ESP-IDF 5.5.4 demo): an ESP32-P4 on
 * the board itself with the JC1060P470C's I2C / codec clocks / SD / C6 pins and RX8025T, but its own panel,
 * touch controller and audio data-in / amplifier pins. No Ethernet PHY. */
#define ROS_BOARD_NAME          "Guition JC8012P4A1"
#define ROS_BOARD_SHORT         "JC8012P4A1"
#define ROS_BOARD_CAMERA        "OV02C10  1288x728"     /* FPC5, CSI - the vendor's sensor; not checked yet */
#define ROS_BOARD_SD_PWR_GPIO   (-1)       /* TF_VCC: LDO 4 */
#define ROS_BOARD_RTC_RX8025T   1          /* U9 RX8025T-UC on I2C 7/8, CR1220 */
#define ROS_BOARD_PANEL_NAME    "10.1\"  800 x 1280  JD9365, MIPI-DSI 2-lane"
#define ROS_BOARD_PANEL_W       800        /* the panel's own scan: vertical */
#define ROS_BOARD_PANEL_H       1280
#define ROS_BOARD_PANEL_VARIANTS 2         /* sold with two panels: the vendor's New_Panel (0) / Old_Panel (1) */
#define ROS_BOARD_PANEL_DEFAULT  1         /* the old one: on the board here (2026-10-06; the new one's settings
                                            * left it black). Settings > Display > Panel, or hold a finger on
                                            * the screen 10 s in the first minute (ros_shell.c) */
#define ROS_BOARD_TOUCH_NAME    "GSL3680"  /* components/esp_lcd_touch_gsl3680 (the vendor's driver) */
#define ROS_BOARD_TOUCH_GT911   0
#define ROS_BOARD_HAS_ETH       0          /* no PHY */
#define ROS_BOARD_DEFAULT_ORIENT ROS_ORIENT_HORIZONTAL   /* 1280x800 (2026-10-06, the user at the board) */
#define ROS_BOARD_PANEL_UPSIDE_DOWN 1      /* the panel sits head-down in the frame (the camera is at the bottom
                                            * the panel's own way): main.c turns every orientation 180° more, so
                                            * "Vertical" is upright and horizontal has the camera on top (the
                                            * user's photo, 2026-10-06) */
#define ROS_BOARD_CONSOLE_UART  1          /* console and probe on UART0 = the CH340 USB-C port (the vendor's
                                            * flashing port); the log goes to USB Serial/JTAG as well */
#define ROS_BOARD_BP_RX         (-1)       /* monitors on USB */
#define ROS_BOARD_BP_RX_NAME    ""
#define ROS_BOARD_SCAN_RX       (-1)
#define ROS_BOARD_SCAN_RX_NAME  ""
/* No card socket (IO1-5 are on the expansion connector FPC3) */
#define ROS_SCG_PIN_IO          (-1)
#define ROS_SCG_PIN_CLK         (-1)
#define ROS_SCG_PIN_RST         (-1)
#define ROS_SCG_PIN_VCC         (-1)
#define ROS_SCG_PIN_DET         (-1)

#elif CONFIG_ROS_BOARD_WS_TOUCH_LCD_101

/* Waveshare ESP32-P4-WIFI6-Touch-LCD-10.1 (schematic ESP32-P4-WIFI6-Touch-LCD-X - the 7" / 8" / 10.1" boards
 * share it - with the ESP32-P4 Connect Adapter that carries the two USB-C ports and two microphones; the board
 * here, 2026-10-06: P4 rev v1.3). An ESP32-P4NRW32 (32 MB PSRAM in the package) on the board with a 32 MB
 * GD25Q256 flash; the reference design's I2C / I2S clocks / SD / C6 pins (IO6 goes to the C6's IO2 as well,
 * unused), the MaTouch's audio data-in and amplifier pins, its own display, touch and backlight pins. The
 * microphones go through an ES7210 four-channel ADC (the ES8311's ASDOUT is not wired). No Ethernet PHY, no
 * clock chip. The 40-pin header J8 carries IO2-5, 7, 8, 21, 22, 24, 25 (the full-speed USB), 28-32, 34, 35,
 * 37, 38 (UART0, shared with the CH343), 46-52 and the high-speed USB pins. */
#define ROS_BOARD_NAME          "Waveshare ESP32-P4-WIFI6-Touch-LCD-10.1"
#define ROS_BOARD_SHORT         "WS-Touch-LCD-10.1"
#define ROS_BOARD_CAMERA        "OV5647  1280x960"      /* CSI-10.1inch FPC J5, 2-lane; the vendor's module */
#define ROS_BOARD_CAMERA_ROT    1          /* the module sits a quarter turn off: its picture is turned 90 degrees
                                            * counter-clockwise (horizontal, 2026-10-07: "up" pointed right) */
#define ROS_BOARD_SD_PWR_GPIO   (-1)       /* SD1_VDD: 3.3 V through an always-on switch (Q1); pull-ups on LDO 4 */
#define ROS_BOARD_RTC_RX8025T   0          /* no clock chip: NTP */
#define ROS_BOARD_PANEL_NAME    "10.1\"  800 x 1280  JD9365, MIPI-DSI 2-lane"
#define ROS_BOARD_PANEL_W       800        /* the panel's own scan: vertical */
#define ROS_BOARD_PANEL_H       1280
#define ROS_BOARD_CLOCK_BACKUP  0          /* nothing keeps the time through power-off: NTP after every start (a
                                            * LiPo on J13 keeps the whole board running instead) */
#define ROS_BOARD_HAS_ETH       0          /* no PHY */
#define ROS_BOARD_DEFAULT_ORIENT ROS_ORIENT_HORIZONTAL   /* 1280x800, the way the vendor shows it */
#define ROS_BOARD_CONSOLE_UART  1          /* console and probe on UART0 = the adapter's "UART" USB-C port (CH343P),
                                            * the vendor's flashing port. The log goes to USB Serial/JTAG as well:
                                            * the adapter's "USB" port is the P4's high-speed PHY, which the USB
                                            * host takes once Reload OS is up (the full-speed one is IO24/25, on J8) */
#define ROS_BOARD_USB_FS_PORT   0          /* the P4's full-speed USB (IO24/25) is on the header only - no "USB_OTG"
                                            * connector. Starting the USB device (TinyUSB) on it switched this board's
                                            * backlight off for good whenever the screen was turned (2026-10-06, see
                                            * docs/drivers/ws101.md) - so the PC link is not offered here */
#define ROS_BOARD_BP_RX         (-1)       /* monitors on USB */
#define ROS_BOARD_BP_RX_NAME    ""
#define ROS_BOARD_SCAN_RX       (-1)       /* scanners: USB only */
#define ROS_BOARD_SCAN_RX_NAME  ""
/* No card socket. A reader goes to the 40-pin header J8 (free: IO2-5, 21, 22, 28-32, 34, 46-52) - then set these */
#define ROS_SCG_PIN_IO          (-1)
#define ROS_SCG_PIN_CLK         (-1)
#define ROS_SCG_PIN_RST         (-1)
#define ROS_SCG_PIN_VCC         (-1)
#define ROS_SCG_PIN_DET         (-1)

#elif CONFIG_ROS_BOARD_JC4880P443

#define ROS_BOARD_NAME          "Guition JC4880P443"
#define ROS_BOARD_SHORT         "JC4880P443"
#define ROS_BOARD_CAMERA        "OV02C10  1288x728"     /* FPC2, 2-lane CSI, SCCB on IO7/8 - not checked yet */
#define ROS_BOARD_SD_PWR_GPIO   (-1)       /* TF_VCC: LDO 4 through an always-on switch */
#define ROS_BOARD_RTC_RX8025T   0          /* no clock chip: NTP */
#define ROS_BOARD_PANEL_NAME    "4.3\"  480 x 800  ST7701, MIPI-DSI 2-lane"
#define ROS_BOARD_PANEL_W       480        /* the panel's own scan: vertical */
#define ROS_BOARD_PANEL_H       800
#define ROS_BOARD_CLOCK_BACKUP  0          /* nothing keeps the time through power-off: NTP after every start */
#define ROS_BOARD_HAS_ETH       0          /* no PHY (the EMAC would only time out at every start). JP1 carries
                                            * the RMII signals by name (IO28-31, 34, 35, 49-52) for a module */
#define ROS_BOARD_DEFAULT_ORIENT ROS_ORIENT_VERTICAL     /* the panel's own way: no turning */
#define ROS_BOARD_BP_RX         (-1)       /* monitors on USB. RS485 (MAX485, auto-direction): RX IO27, TX IO26 */
#define ROS_BOARD_BP_RX_NAME    ""
#define ROS_BOARD_SCAN_RX       (-1)       /* scanners: USB only */
#define ROS_BOARD_SCAN_RX_NAME  ""
/* No smart-card socket: IO1-4 are pads on the module, routed nowhere, and IO5 is the LCD reset. A
 * reader goes to the JP1 header (free: IO28-34, IO49-52; IO35 is the boot strap) - then set these. */
#define ROS_SCG_PIN_IO          (-1)
#define ROS_SCG_PIN_CLK         (-1)
#define ROS_SCG_PIN_RST         (-1)
#define ROS_SCG_PIN_VCC         (-1)
#define ROS_SCG_PIN_DET         (-1)

#elif CONFIG_ROS_BOARD_ESP32_P4_FUNCTION_EV

/* Espressif ESP32-P4-Function-EV-Board (schematic v1.4, 2024-07-02): the reference design this BSP and the other P4
 * boards follow - I2C 7/8, I2S 13/12/10/9 with the codec's data on 11 (ASDOUT) and 9 (DSDIN), amplifier enable 53,
 * microSD 39-44, the C6-MINI-1 on SDIO 14-19 (EN 54, WAKEUP 6), an IP101GR on RMII (MDC 31, MDIO 52, reset 51, its
 * 50 MHz into 50). An ESP32-P4NRW32 (32 MB PSRAM in the package) with a 16 MB flash. The 7" 1024x600 EK79007 kit sits
 * on the DSI connector J5, which carries the lanes, the I2C and 3V3 only: its adapter board brings LCD reset and the
 * backlight PWM to the pin header J1 by wire - IO21 and IO23 on the kit here (the BSP header; Espressif's guide has
 * IO27 / IO26, which are the full-speed USB OTG).
 * GT911 touch on the same I2C, no reset or interrupt line to the P4. SC2336 camera on the CSI connector J9 (its reset
 * pulled up; no GPIO). Four USB sockets: Type-C on the P4's full-speed USB (IO24/25: USB Serial/JTAG - the console, the
 * probe and flashing; the PC link is the full-speed OTG on IO26/27: J20 on v1.5, J1 pins 31/38 on v1.4), Type-C
 * "USB-UART" (a CP2102N on UART0, IO37/38, on v1.4 boards; unused here),
 * and a Type-C OTG and a Type-A host on the one high-speed PHY (the USB host port; not both at once). A 2-pin BAT
 * header, no battery holder. The board here (2026-10-20) has an ESP32-P4 rev v3.2: its build is the v3 family
 * (sdkconfig.defaults.esp32_p4_function_ev), the first in Reload OS. */
#define ROS_BOARD_NAME          "Espressif ESP32-P4-Function-EV-Board"
#define ROS_BOARD_SHORT         "P4-Function-EV"
#define ROS_BOARD_CAMERA        "SC2336  1280x720"      /* Espressif's module on J9, 2-lane - not checked yet */
#define ROS_BOARD_SD_PWR_GPIO   45         /* SD_PWRn -> Q8 P-MOSFET, low = on; R229 holds it low, so the card is
                                            * powered until the pin is driven (the MaTouch's gate floats instead) */
#define ROS_BOARD_RTC_RX8025T   0          /* no clock chip: NTP */
#if CONFIG_BSP_LCD_TYPE_HDMI
/* The HDMI image (tools/build.sh evhdmi): an LT8912B MIPI-DSI to HDMI converter on the DSI connector J5 instead of the
 * 7" kit - a monitor at the video mode CONFIG_BSP_LCD_HDMI_* chooses (the BSP), no touch: a USB mouse / keyboard on the
 * USB host, or the remote desktop. docs/drivers/hdmi-lt8912b.md */
#define ROS_BOARD_HAS_HDMI      1
#define ROS_BOARD_HAS_TOUCH     0
#define ROS_BOARD_TOUCH_NAME    "none"
#define ROS_BOARD_TOUCH_GT911   0
#if CONFIG_BSP_LCD_HDMI_800x600_60HZ
#define ROS_BOARD_PANEL_W       800
#define ROS_BOARD_PANEL_H       600
#define ROS_BOARD_PANEL_NAME    "HDMI  800 x 600 @ 60 Hz  (LT8912B converter)"
#elif CONFIG_BSP_LCD_HDMI_1024x768_60HZ
#define ROS_BOARD_PANEL_W       1024
#define ROS_BOARD_PANEL_H       768
#define ROS_BOARD_PANEL_NAME    "HDMI  1024 x 768 @ 60 Hz  (LT8912B converter)"
#elif CONFIG_BSP_LCD_HDMI_1280x800_60HZ
#define ROS_BOARD_PANEL_W       1280
#define ROS_BOARD_PANEL_H       800
#define ROS_BOARD_PANEL_NAME    "HDMI  1280 x 800 @ 60 Hz  (LT8912B converter)"
#elif CONFIG_BSP_LCD_HDMI_1920x1080_30HZ
#define ROS_BOARD_PANEL_W       1920
#define ROS_BOARD_PANEL_H       1080
#define ROS_BOARD_PANEL_NAME    "HDMI  1920 x 1080 @ 30 Hz  (LT8912B converter)"
#else
#define ROS_BOARD_PANEL_W       1280
#define ROS_BOARD_PANEL_H       720
#define ROS_BOARD_PANEL_NAME    "HDMI  1280 x 720 @ 60 Hz  (LT8912B converter)"
#endif
#else
#define ROS_BOARD_PANEL_NAME    "7\"  1024 x 600  EK79007, MIPI-DSI 2-lane"
#define ROS_BOARD_PANEL_W       1024
#define ROS_BOARD_PANEL_H       600
#endif
#define ROS_BOARD_CLOCK_BACKUP  1          /* the P4's LP timer on a coin cell at the test pads TP2 (BAT +) / TP1 (GND):
                                            * fit R196, remove R198 (never both). Without the cell, VBAT comes from
                                            * 3.3 V through R198: the time is kept through a restart, not a power-off */
#define ROS_BOARD_CLOCK_CELL    "coin cell"  /* none comes with the board: a CR2032 or a CR1220 */
#define ROS_BOARD_CONSOLE_UART  0          /* console and probe on USB Serial/JTAG (the full-speed Type-C,
                                            * /dev/cu.usbmodem*), as the JC1060P470C; UART0 carries nothing */
#define ROS_BOARD_BP_RX         (-1)       /* monitors on USB */
#define ROS_BOARD_BP_RX_NAME    ""
#define ROS_BOARD_SCAN_RX       (-1)       /* scanners: USB only */
#define ROS_BOARD_SCAN_RX_NAME  ""
/* Smart card (ISO 7816, ros_scgpio.c) wired to the 40-pin header J1, the MaTouch's pins on the same header layout (one
 * harness fits both): C7 I/O -> IO32 (pin 26, open drain, pull-up), C3 CLK -> IO33 (pin 29), C2 RST -> IO46 (pin 36),
 * C1 VCC <- IO47 (pin 37, high = on: the enable of a card power switch), the socket's card switch -> IO48 (pin 33, to
 * GND = card in), C5 GND -> pin 30 / 34. The ADC pins IO20 / IO22 stay free. Nothing is driven until the switch closes. */
#define ROS_SCG_PIN_IO          32
#define ROS_SCG_PIN_CLK         33
#define ROS_SCG_PIN_RST         46
#define ROS_SCG_PIN_VCC         47
#define ROS_SCG_PIN_DET         48

#else   /* CONFIG_ROS_BOARD_MATOUCH_P4_7 */

#define ROS_BOARD_NAME          "MaTouch ESP32-P4 7\" (Makerfabs)"
#define ROS_BOARD_SHORT         "MaTouch ESP32-P4"
#define ROS_BOARD_CAMERA        "SC2336  1280x720"
/* microSD power switch (schematic V1.2, "TF Card"): Q1 P-MOSFET MKF_3V3 -> SD1_VDD, gate from
 * IO45 via R71 with 10K up + 10K down, so undriven the gate floats at ~1.65 V and the card is
 * only half powered. Low = card on. (IO54 is C6_EN - the Wi-Fi chip's reset.) */
#define ROS_BOARD_SD_PWR_GPIO   45
#define ROS_BOARD_RTC_RX8025T   0
#define ROS_BOARD_BP_RX         4          /* Grove J1 pin 2 */
#define ROS_BOARD_BP_RX_NAME    "Grove J1"
#define ROS_BOARD_SCAN_RX       (-1)       /* scanners: USB only */
#define ROS_BOARD_SCAN_RX_NAME  ""
/* Smart card wired to the 40-pin header: C7 I/O -> IO32 (pin 26, open drain, pull-up), C3 CLK ->
 * IO33 (pin 29), C2 RST -> IO46 (pin 36), C1 VCC <- IO47 (pin 37, drives the card power switch),
 * socket card switch -> IO48 (pin 33, low = card in), C5 GND -> pin 30/34. */
#define ROS_SCG_PIN_IO          32
#define ROS_SCG_PIN_CLK         33
#define ROS_SCG_PIN_RST         46
#define ROS_SCG_PIN_VCC         47
#define ROS_SCG_PIN_DET         48

#endif

/* What most boards have; a board that differs says so above */
#ifndef ROS_BOARD_PANEL_W
#define ROS_BOARD_PANEL_NAME    "7\"  1024 x 600  JD9165, MIPI-DSI 2-lane"
#define ROS_BOARD_PANEL_W       1024       /* 7" JD9165, scanned horizontally */
#define ROS_BOARD_PANEL_H       600
#endif
#ifndef ROS_BOARD_HAS_ETH
#define ROS_BOARD_HAS_ETH       1          /* IP101 on RMII */
#endif
#ifndef ROS_BOARD_ETH_RMII_PINS
#define ROS_BOARD_ETH_RMII_PINS 0          /* the EMAC on the chip's default pins (ETH_ESP32_EMAC_DEFAULT_CONFIG: the P4's
                                            * reference wiring) - a board that differs gives ROS_BOARD_ETH_MDC ... above */
#endif
#ifndef ROS_BOARD_ETH_RST_GPIO
#define ROS_BOARD_ETH_RST_GPIO  51         /* the PHY's reset: the P4 reference wiring */
#endif
#ifndef ROS_BOARD_PANEL_VARIANTS
#define ROS_BOARD_PANEL_VARIANTS 1         /* one panel: no choice in Settings */
#define ROS_BOARD_PANEL_DEFAULT  0
#endif
#ifndef ROS_BOARD_HAS_TOUCH
#define ROS_BOARD_HAS_TOUCH     1          /* a touch controller on the panel (an HDMI monitor has none) */
#endif
#ifndef ROS_BOARD_HAS_HDMI
#define ROS_BOARD_HAS_HDMI      0          /* a MIPI-DSI to HDMI converter instead of a panel (bsp_display_hdmi_connected()) */
#endif
#ifndef ROS_BOARD_TOUCH_NAME
#define ROS_BOARD_TOUCH_NAME    "GT911"
#define ROS_BOARD_TOUCH_GT911   1          /* components/espressif__esp_lcd_touch_gt911, with its recovery */
#endif
#ifndef ROS_BOARD_CLOCK_BACKUP
#define ROS_BOARD_CLOCK_BACKUP  1          /* a CR1220 keeps the time: the RX8025T's, or the P4's LP timer on VDD_BAT */
#endif
#ifndef ROS_BOARD_CLOCK_CELL
#define ROS_BOARD_CLOCK_CELL    "CR1220"   /* what Settings > Time names the P4's clock battery */
#endif
#ifndef ROS_BOARD_CONSOLE_UART
#define ROS_BOARD_CONSOLE_UART  0          /* the probe talks over USB Serial/JTAG */
#endif
#ifndef ROS_BOARD_CAMERA_ROT
#define ROS_BOARD_CAMERA_ROT    0          /* quarter turns counter-clockwise the camera's picture needs (ros_camera.c) */
#endif
#ifndef ROS_BOARD_USB_FS_PORT
#define ROS_BOARD_USB_FS_PORT   1          /* the "USB_OTG" connector: the P4's full-speed port, the PC link (ros_usbdev.c)
                                            * or the second USB host port (Settings > USB) */
#endif
#ifndef ROS_BOARD_USB_HS_DEVICE
#define ROS_BOARD_USB_HS_DEVICE 0          /* 1: the high-speed socket is the PC link when Settings > USB says so (a P4
                                            * board whose full-speed OTG has no socket: the JC1060P470C); the host else */
#endif
#ifndef ROS_BOARD_DEFAULT_ORIENT
#define ROS_BOARD_DEFAULT_ORIENT ROS_ORIENT_HORIZONTAL
#endif
#ifndef ROS_BOARD_HAS_USB
#define ROS_BOARD_HAS_USB       1          /* the USB host (ros_usb.c) - and the PC link where ROS_BOARD_USB_FS_PORT */
#endif
#ifndef ROS_BOARD_HAS_CAMERA
#define ROS_BOARD_HAS_CAMERA    1          /* a MIPI-CSI camera (ros_camera.c); USB cameras need ROS_BOARD_HAS_USB */
#endif
#ifndef ROS_BOARD_SERIAL_RX_ALT
#define ROS_BOARD_SERIAL_RX_ALT { -1 }     /* serial devices only on ROS_BOARD_BP_RX / ROS_BOARD_SCAN_RX */
#endif
#ifndef ROS_BOARD_LED_CARD
#define ROS_BOARD_LED_CARD      (-1)       /* the kiosk app's guide LEDs: none */
#define ROS_BOARD_LED_CODE      (-1)
#endif
#ifndef ROS_BOARD_HAS_MIC
#define ROS_BOARD_HAS_MIC       1          /* the codec's microphone input (Recorder, voice) */
#endif
#ifndef ROS_BOARD_AUDIO_CHIP
#define ROS_BOARD_AUDIO_CHIP    "ES8311"   /* the codec by name (the Factory test's line) */
#endif
#ifndef ROS_BOARD_AUDIO_CODEC              /* Settings › Sound › Hardware: the P4 boards' reference design */
#define ROS_BOARD_AUDIO_CODEC   "ES8311, 16 kHz 16-bit mono (duplex I2S)"
#define ROS_BOARD_AUDIO_AMP     "NS4150B, 3 W class-D"
#endif
#ifndef ROS_BOARD_FLASH_MB                 /* the least flash and PSRAM a good board has (the Factory test's Memory) */
#define ROS_BOARD_FLASH_MB      16
#define ROS_BOARD_PSRAM_MB      32         /* the P4's own, in the package */
#endif
#ifndef ROS_BOARD_PANEL_UPSIDE_DOWN
#define ROS_BOARD_PANEL_UPSIDE_DOWN 0      /* the panel's own way is the right way up */
#endif
#define ROS_BOARD_HAS_SCG       (ROS_SCG_PIN_IO >= 0)     /* a smart-card socket on GPIOs (ros_scgpio.c) */

/* What comes with the chip, not the board: the P4's accelerators and its Wi-Fi co-processor (an ESP32-C6 on SDIO,
 * esp_hosted) - the S3 has neither, but its own radio */
#if SOC_PPA_SUPPORTED
#define ROS_HAS_PPA             1          /* pixel-processing accelerator: turning, scaling */
#else
#define ROS_HAS_PPA             0
#endif
#if SOC_JPEG_CODEC_SUPPORTED
#define ROS_HAS_HW_JPEG         1          /* JPEG decoder / encoder (the S3 decodes and encodes in software: ros_swjpeg.c) */
#else
#define ROS_HAS_HW_JPEG         0
#endif
/* PSRAM as DMA memory: the P4's heap gives its PSRAM MALLOC_CAP_DMA (the SD card, the codecs and the PPA work on it
 * directly); the S3's does not - an allocation asking for both MALLOC_CAP_SPIRAM and MALLOC_CAP_DMA returns NULL there.
 * A PSRAM buffer a driver may DMA into therefore asks ROS_CAPS_PSRAM_DMA: DMA-capable on the P4, plain PSRAM on the S3
 * (its SD card on SPI and its flash copy through their drivers' own internal buffers) */
#if CONFIG_IDF_TARGET_ESP32P4 || CONFIG_IDF_TARGET_ESP32S31
#define ROS_PSRAM_DMA           1          /* the S31 is of the P4's generation (SOC_PSRAM_DMA_CAPABLE) */
#else
#define ROS_PSRAM_DMA           0
#endif
#define ROS_CAPS_PSRAM_DMA      (MALLOC_CAP_SPIRAM | (ROS_PSRAM_DMA ? MALLOC_CAP_DMA : 0))
#if ROS_HAS_HW_JPEG
#define ROS_JPEG_HOW            "by the hardware JPEG encoder"      /* for texts on screen */
#else
#define ROS_JPEG_HOW            "in software (no JPEG encoder in this chip)"
#endif
#if CONFIG_IDF_TARGET_ESP32P4
#define ROS_HAS_C6              1          /* Wi-Fi / Bluetooth through the C6 (ros_cpfw.c) */
#define ROS_CHIP_NAME           "ESP32-P4"
#elif CONFIG_IDF_TARGET_ESP32S31
#define ROS_HAS_C6              0          /* the chip's own radio */
#define ROS_CHIP_NAME           "ESP32-S31"
/* A software restart (esp_restart(), a crash) resets this chip's CPUs alone: ESP-IDF's S31 port resets no peripheral on
 * the way out, and what kept running does not work in the next run - ros_health_whole_reset() (ros_health.c) */
#define ROS_SW_RESET_CPU_ONLY   1
/* One USB OTG in the chip, high-speed: a board's socket is the USB host or the PC link, never both at once (the P4 has
 * two, one for each). Which: the setting "USB_OTG port" where the board's socket can be a device's
 * (ROS_BOARD_USB_FS_PORT), else the host. */
#define ROS_USB_ONE_HS_PORT     1
#else
#define ROS_HAS_C6              0          /* the chip's own radio */
#define ROS_CHIP_NAME           "ESP32-S3"
#endif
#ifndef ROS_USB_ONE_HS_PORT
#define ROS_USB_ONE_HS_PORT     0
#endif
#ifndef ROS_BOARD_USB_VBUS_OUT
#define ROS_BOARD_USB_VBUS_OUT  0          /* the PC link's socket takes 5 V in only (the P4 boards: an ideal-diode OR) */
#endif
/* One socket for both roles - the host or the PC link, by Settings > USB: the ESP32-S31 boards (one OTG in the chip),
 * and a P4 board whose full-speed OTG has no socket (ROS_BOARD_USB_HS_DEVICE: its high-speed socket is the PC link then) */
#define ROS_USB_ONE_SOCKET      (ROS_USB_ONE_HS_PORT || ROS_BOARD_USB_HS_DEVICE)
/* What the USB sockets are called to the user (Settings > USB, Files, the logs): the P4 boards have "USB Native" (the
 * host) and "USB_OTG" (the PC link, or the host by the setting); a one-socket board has the one USB port for both roles */
#if ROS_USB_ONE_SOCKET
#define ROS_USB_HOST_PORT_NAME  "the USB port"
#define ROS_USB_DEV_PORT_NAME   "the USB port"
#else
#define ROS_USB_HOST_PORT_NAME  "USB Native"
#define ROS_USB_DEV_PORT_NAME   "USB_OTG"
#endif
#ifndef ROS_SW_RESET_CPU_ONLY
#define ROS_SW_RESET_CPU_ONLY   0          /* ESP-IDF resets the chip's peripherals at a software restart */
#endif
