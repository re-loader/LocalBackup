#!/bin/bash
# Start a new app from the Hello example:
#   ./new.sh myapp        -> myapp/ (a copy of hello/ with the name changed)   then: ./build.sh myapp
# The name is also the file name on the device (myapp.elf) - a-z, 0-9 and _, starting with a letter.
cd "$(dirname "$0")" || exit 1
name=$1
[[ "$name" =~ ^[a-z][a-z0-9_]{0,22}$ ]] || { echo "usage: ./new.sh <name: a-z 0-9 _, starting with a letter>"; exit 1; }
[ -e "$name" ] && { echo "$name exists already"; exit 1; }
[ "$name" = hello ] && { echo "hello is the example itself"; exit 1; }
Name="$(printf '%s' "${name:0:1}" | tr '[:lower:]' '[:upper:]')${name:1}"
mkdir -p "$name/main"
sed "s/hello/$name/g; s/Hello/$Name/g" hello/CMakeLists.txt > "$name/CMakeLists.txt"
sed "s/hello/$name/g; s/Hello/$Name/g" hello/main/CMakeLists.txt > "$name/main/CMakeLists.txt"
sed "s/hello/$name/g; s/Hello/$Name/g" hello/main/hello.c > "$name/main/$name.c"
cp hello/main/idf_component.yml "$name/main/"
echo "$name/ made from the Hello example. Next: edit $name/main/$name.c, then  ./build.sh $name"
