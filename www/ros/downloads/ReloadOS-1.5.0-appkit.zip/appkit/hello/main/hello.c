/*
 * Hello - the smallest Reload OS app that runs from the flash drive or the SD card. Start another one
 * with tools/newapp.sh (in the firmware tree) or ./new.sh (in the app kit, tools/mkappkit.sh).
 *
 * Everything an app calls comes from the firmware's API table (main/ros_elfapp_api.c; reloados/api.txt
 * in the kit): ros_* from ros.h, the lv_* functions the firmware uses, the Montserrat fonts, and libc.
 * main() only hands its ros_elfapp_t back; the work starts in create(), like any app.
 */
#include "ros.h"

static lv_obj_t *s_count, *s_mem;
static lv_timer_t *s_timer;
static int s_n;

static void tick(lv_timer_t *t)
{
    lv_label_set_text_fmt(s_count, "%d", ++s_n);
}

static void hello_cb(lv_event_t *e)
{
    ros_audio_click();
    ros_toast(LV_SYMBOL_OK "  Hello from the SD card");
}

static void create(lv_obj_t *body)
{
    s_n = 0;
    lv_obj_set_flex_flow(body, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_flex_align(body, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
    lv_obj_set_style_pad_row(body, 18, 0);
    ros_ui_label(body, &lv_font_montserrat_32, ROS_C_TEXT, LV_SYMBOL_SD_CARD "  Hello");
    lv_obj_t *info = ros_ui_label(body, &lv_font_montserrat_16, ROS_C_MUTED,
                                  "This app is not in the firmware: it was loaded from "
                                  "apps/hello.elf on the flash drive or the SD card when you opened it.");
    lv_obj_set_style_text_align(info, LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_set_width(info, lv_pct(90));                 /* wraps on a narrow screen (480 px) */
    lv_label_set_long_mode(info, LV_LABEL_LONG_WRAP);
    s_count = ros_ui_label(body, &lv_font_montserrat_48, ROS_C_ACCENT, "0");
    s_mem = ros_ui_label(body, &lv_font_montserrat_14, ROS_C_MUTED, "");
    lv_label_set_text_fmt(s_mem, "Screen %d x %d  -  %s", ROS_SCR_W, ROS_SCR_H, ROS_PORTRAIT ? "vertical" : "horizontal");
    lv_obj_t *b = ros_ui_button(body, LV_SYMBOL_BELL "  Say hello", ROS_C_ACCENT);
    lv_obj_add_event_cb(b, hello_cb, LV_EVENT_CLICKED, NULL);
    s_timer = lv_timer_create(tick, 1000, NULL);
}

static void destroy(void)
{
    if (s_timer) lv_timer_delete(s_timer);
    s_timer = NULL;
}

ROS_ELFAPP_META("Hello", LV_SYMBOL_SD_CARD, 0x6B4FBB);     /* the launcher's tile, read without loading the app */

static const ros_elfapp_t s_app = {
    .abi = ROS_ELFAPP_ABI,
    .app = { .name = "Hello", .icon = LV_SYMBOL_SD_CARD, .color = 0x6B4FBB, .create = create, .destroy = destroy },
    .board = ROS_BOARD_SHORT,           /* the firmware refuses an app built for the other board */
    .meta = &ros_elfapp_meta,
    /* .tasks: an app with tasks of its own counts them; Hello has none */
};

int main(int argc, char *argv[])
{
    if (argc > 0 && argv[0]) *(const ros_elfapp_t **)argv[0] = &s_app;
    return 0;
}
