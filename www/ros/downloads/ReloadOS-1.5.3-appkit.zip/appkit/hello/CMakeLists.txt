# A Reload OS app that runs from the SD card (README.md). Build: ./build.sh hello
cmake_minimum_required(VERSION 3.16)
include(${CMAKE_CURRENT_LIST_DIR}/../reloados/elfapp.cmake)
include($ENV{IDF_PATH}/tools/cmake/project.cmake)
project(hello)
include(elf_loader)
project_elf(hello)
