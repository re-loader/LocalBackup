# ros.h comes from the firmware (../../reloados/main); it includes LVGL and the JPEG driver headers
idf_component_register(SRCS "hello.c"
                       INCLUDE_DIRS "." "../../reloados/main"
                       REQUIRES lvgl__lvgl esp_driver_jpeg)
