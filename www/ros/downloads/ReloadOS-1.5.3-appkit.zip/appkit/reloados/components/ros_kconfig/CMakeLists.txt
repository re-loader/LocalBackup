# The firmware's own Kconfig menu ("Reload OS": board, product ...) for the apps in elfapps/, so that
# CONFIG_ROS_BOARD_* from the board's defaults reaches ros_board.h as it does in the firmware
idf_component_register()
